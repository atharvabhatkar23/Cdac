package com.stack.core;

public interface Stack {
	int size=2;//public static final added by the compiler
	void push(Customer c); //public abstract added by compiler
	void pop();//public abstract added by compiler
	
}
