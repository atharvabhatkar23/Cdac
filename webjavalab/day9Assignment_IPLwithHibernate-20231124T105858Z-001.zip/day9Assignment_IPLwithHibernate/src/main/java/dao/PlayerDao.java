package dao;

import pojos.Player;

public interface PlayerDao {
	String addPlayerDetails(Player newPlayer);
}
